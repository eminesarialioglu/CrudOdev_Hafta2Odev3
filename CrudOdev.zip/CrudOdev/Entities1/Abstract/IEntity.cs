﻿using Entities.Concreate;

namespace Entities.Abstract
{
    interface IEntity
    {
        
    }
}
