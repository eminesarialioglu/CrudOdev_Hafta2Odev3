﻿using Entities.Concreate;

namespace Entities.Abstract
{
    public interface IEntity
    {

    }
}
