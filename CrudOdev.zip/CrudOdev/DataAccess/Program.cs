﻿using System;
using DataAccess.Concreate;

class Program

{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}