﻿using Entities.Concreate;
using DataAccess.Abstract;

namespace DataAccess.Concreate
{
    public class CourseDal:ICourseDal
    {
       List<Course> _courses;
        public CourseDal()
        {
            Course course1=new Course() { Id = 1, CategoryId = 1, InstructorId = 1, Name = ".NET", Description = "Yazılım Geliştirici Yetiştirme Kampı", Price = 0 };
            Course course2 = new Course() { Id = 2, CategoryId = 1, InstructorId = 2, Name = "Python", Description = "Yazılım Geliştirici Yetiştirme Kampı", Price = 0 };
            Course course3 = new Course() { Id = 3, CategoryId = 1, InstructorId = 1, Name = "Javascript", Description = "Yazılım Geliştirici Yetiştirme Kampı", Price = 0 };
            Course course4 = new Course() { Id = 4, CategoryId = 1, InstructorId = 1, Name = "Java", Description = "Yazılım Geliştirici Yetiştirme Kampı", Price = 0};
            Course course5 = new Course() { Id = 5, CategoryId = 1, InstructorId = 1, Name = "C#", Description = "Yazılımcı Geliştirici Yetiştirme Kampı", Price = 0 };
            Course course7 = new Course() { Id = 7, CategoryId = 1, InstructorId = 1, Name = "Temel Kurs", Description = "Programlamaya Giriş İçin Temel Kurs", Price = 0 };

        }
        public void Add(Course course)
        {
            _courses.Add(course);
        }

        public void Update(Course course)
        {
            var courseToUpdate = _courses.FirstOrDefault(c => c.Id == course.Id);
            if (courseToUpdate != null)
            {
                courseToUpdate.Name = course.Name;
                courseToUpdate.InstructorId = course.InstructorId;
                courseToUpdate.CategoryId = course.CategoryId;
                courseToUpdate.Description = course.Description;
                courseToUpdate.Price = course.Price;
                
                
            }

        }
        public void Delete(Course course)
        {
            var courseToDelete = _courses.FirstOrDefault(c => c.Id == course.Id);
            if (courseToDelete != null)
            {
                courseToDelete.Name = course.Name;
                courseToDelete.InstructorId = course.InstructorId;
                courseToDelete.CategoryId = course.CategoryId;
                courseToDelete.Description = course.Description;
                courseToDelete.Price = course.Price;
                

            }

        }

    }
}
