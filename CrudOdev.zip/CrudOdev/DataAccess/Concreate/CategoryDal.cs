﻿using Entities.Concreate;
using DataAccess.Abstract;
using Entities.Abstract;

namespace DataAccess.Concreate
{
    public class CategoryDal : ICategoryDal
    {
        private List<Category> _categories;

        public CategoryDal()
        {
            _categories = new List<Category>
            {
                new Category { Id = 1, Name = "Tümü", Description = "Programlama" },
                new Category { Id = 2, Name = "Programlama", Description = "Programlama" }
            };
        }

        public void Add(Category category)
        {
            _categories.Add(category);
        }

        public void Update(Category category)
        {
            var categoryToUpdate = _categories.FirstOrDefault(c => c.Id == category.Id);
            if (categoryToUpdate != null)
            {
                categoryToUpdate.Name = category.Name;
                categoryToUpdate.Description = category.Description;
            }
        }

        public void Delete(Category category)
        {
            var categoryToDelete = _categories.FirstOrDefault(c => c.Id == category.Id);
            if (categoryToDelete != null)
            {
                _categories.Remove(categoryToDelete);
            }
        }
    }
}
