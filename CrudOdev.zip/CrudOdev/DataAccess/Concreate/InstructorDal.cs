﻿using Entities.Concreate;
using DataAccess.Abstract;

namespace DataAccess.Concreate
{
    public class InstructorDal : IInstructorDal
    {
        List<Instructor> _instructors;

        public InstructorDal()
        {
            _instructors = new List<Instructor>
            {
                new Instructor{ Id = 1, FirstName = "Engin", LastName = "Demirog" },
                new Instructor{ Id = 2, FirstName = "Halit Enes", LastName = "Kalaycı" }
            };
        }

        public void Add(Instructor instructor)
        {
            _instructors.Add(instructor);
        }

        public void Update(Instructor instructor)
        {
            var instructorToUpdate=_instructors.FirstOrDefault(i=>i.Id== instructor.Id);
            if (instructorToUpdate!=null)
            {
                instructorToUpdate.FirstName = instructor.FirstName;
                instructorToUpdate.LastName= instructor.LastName;
            }

        }
        public void Delete(Instructor instructor)
        {
            var instructorToDelete = _instructors.FirstOrDefault(i => i.Id == instructor.Id);
            if (instructorToDelete != null)
            {
                instructorToDelete.FirstName = instructor.FirstName;
                instructorToDelete.LastName = instructor.LastName;
            }

        }




    }

}

