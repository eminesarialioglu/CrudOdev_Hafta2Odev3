﻿using Entities.Concreate;



namespace DataAccess.Abstract
{
    public interface ICategoryDal
    {
        void Add(Category category);
        void Delete(Category category);
        void Update(Category category);
    }
}
