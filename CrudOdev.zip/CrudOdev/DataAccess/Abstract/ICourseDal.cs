﻿using Entities.Concreate;


namespace DataAccess.Abstract
{
    public interface ICourseDal
    {
        void Add(Course course);
        void Delete(Course course);
        void Update(Course course);
    }
}
