﻿using Entities.Concreate;
using DataAccess.Abstract;
using DataAccess.Concreate;


namespace Business.Abstract;

public interface ICourseServices
{
    void Add(Course course);
    void Delete(Course course);
    void Update(Course course);

}
