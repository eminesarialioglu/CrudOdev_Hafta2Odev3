﻿using Entities.Concreate;
using DataAccess.Abstract;
using DataAccess.Concreate;

namespace Business.Abstract
{
    public interface ICategoryService
    {
        void Add(Category category);
        void Delete(Category category);
        void Update(Category category);
    }
}
