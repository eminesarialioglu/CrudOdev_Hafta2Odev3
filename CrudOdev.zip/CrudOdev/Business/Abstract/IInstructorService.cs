﻿using Entities.Concreate;
using DataAccess.Abstract;
using DataAccess.Concreate;



namespace Business.Abstract
{
    public interface IInstructorService
    {
        void Add(Instructor instructor);
        void Delete(Instructor instructor);
        void Update(Instructor instructor);
    }
}
