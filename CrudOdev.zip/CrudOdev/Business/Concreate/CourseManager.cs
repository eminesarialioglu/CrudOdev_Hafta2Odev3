﻿using Business.Abstract;
using Entities.Concreate;
using DataAccess.Abstract;
using DataAccess.Concreate;


namespace Business.Concreate
{
    public class CourseManager : ICourseServices
    {
        private readonly ICourseDal _courseDal;

        public CourseManager(ICourseDal courseDal)
        {
            _courseDal = courseDal;
        }

        public void Add(Course course)
        {
            _courseDal.Add(course);
        }

        public void Delete(Course course)
        {
            _courseDal.Delete(course);
        }

        public void Update(Course course)
        {
            _courseDal.Update(course);
        }
    }
}
